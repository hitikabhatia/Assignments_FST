package com.tests;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.base.BaseClass;
import com.pages.MainPage;
import com.pages.MainPageUsingPageFactory;

import io.appium.java_client.MobileElement;

public class SmokeTest extends BaseClass {
	
	@Test
	public void firstSmokeTestMethod() throws InterruptedException {
		/*
		 * MainPage mainPageElementObject = new MainPage();
		 * mainPageElementObject.goToDarkTheme(driver); SoftAssert sAssert = new
		 * SoftAssert();
		 * sAssert.assertEquals(mainPageElementObject.getSaveButtonText(driver),
		 * "Save"); sAssert.assertAll(); Thread.sleep(2000);
		 */
		
		MainPageUsingPageFactory mpage = new MainPageUsingPageFactory(driver);
		mpage.goToHintBox();
		Thread.sleep(2000);
	
	}
}
