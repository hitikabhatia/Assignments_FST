package com.pages;

import java.time.Duration;

import org.openqa.selenium.support.PageFactory;

import com.methods.ActionMethods;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class MainPageUsingPageFactory {
	
	public MainPageUsingPageFactory(AndroidDriver<MobileElement> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(5)), this);
	}
	
	@AndroidFindBy(accessibility = "Views")
	private AndroidElement viewsLink;
	
	@AndroidFindBy(accessibility = "Controls")
	private AndroidElement controlLink;
	
	@AndroidFindBy(accessibility = "2. Dark Theme")
	private AndroidElement darkThemeElement;
	
	@AndroidFindBy(id = "io.appium.android.apis:id/edit")
	private AndroidElement hintTextBox;
	
	public void goToHintBox() {
		ActionMethods  aMethod = new ActionMethods();
		aMethod.clickOnElementUsingFactory(viewsLink);
		aMethod.clickOnElementUsingFactory(controlLink);
		aMethod.clickOnElementUsingFactory(darkThemeElement);
		aMethod.enterTextUsingFactory(hintTextBox, "Hello there");
	}
}
