package com.pages;

import org.openqa.selenium.By;

import com.methods.ActionMethods;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class MainPage {
	public MobileBy viewsLink = (MobileBy) MobileBy.AccessibilityId("Views");
	public MobileBy controlLink = (MobileBy) MobileBy.AccessibilityId("Controls");
	public MobileBy darkThemeLink = (MobileBy) MobileBy.AccessibilityId("2. Dark Theme");	
	public By hintTextBoxLink = By.id("io.appium.android.apis:id/edit");
	public By saveButtonLink = By.id("io.appium.android.apis:id/button");
	
	public void goToDarkTheme(AndroidDriver<MobileElement> driver) {
		ActionMethods.clickOnElement(viewsLink, driver);
		ActionMethods.clickOnElement(controlLink, driver);
		ActionMethods.clickOnElement(darkThemeLink, driver);
		ActionMethods.enterText(hintTextBoxLink, "Hello there", driver);
	}

	public String getSaveButtonText(AndroidDriver<MobileElement> driver) {
		return driver.findElement(saveButtonLink).getText();
	}

}
