package com.appium;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import lombok.SneakyThrows;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RecordedAppiumCode {

	private AndroidDriver driver;

	@BeforeClass
	public void setUp() throws MalformedURLException {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability("appium:deviceName", "sdk_gphone_x86");
		desiredCapabilities.setCapability("platformName", "Android");
		desiredCapabilities.setCapability("appium:platformVersion", "11");
		desiredCapabilities.setCapability("appium:appActivity", "io.appium.android.apis.ApiDemos");
		desiredCapabilities.setCapability("appium:appPackage", "io.appium.android.apis");
		desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
		desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
		desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
		desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);

		URL remoteUrl = new URL("http://127.0.0.1:4723/wd/hub/");

		driver = new AndroidDriver(remoteUrl, desiredCapabilities);
	}

	public void sampleTest() throws InterruptedException {
		MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Views");
		el1.click();
		MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("Controls");
		el2.click();
		MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("2. Dark Theme");
		el3.click();
		MobileElement el4 = (MobileElement) driver.findElementByAccessibilityId("Checkbox 1");
		el4.click();
		Thread.sleep(2000);
		MobileElement el5 = (MobileElement) driver.findElementByAccessibilityId("RadioButton 1");
		el5.click();
		Thread.sleep(2000);
		driver.findElementById("io.appium.android.apis:id/toggle1").click();
		Thread.sleep(2000);
	}
	
	public void dropDown() throws InterruptedException {
		MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Views");
		el1.click();
		MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("Controls");
		el2.click();
		MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("2. Dark Theme");
		el3.click();
		driver.findElementById("io.appium.android.apis:id/spinner1").click();
		List<MobileElement> myDropDown = driver.findElementsByXPath("//android.widget.CheckedTextView");
		for (MobileElement mobileElement : myDropDown) {
			if(mobileElement.getText().equalsIgnoreCase("Jupiter")) {
				mobileElement.click();
				System.out.println("We have reached Jupiter");
				Thread.sleep(2000);
				break;
			}
		}
	}
	
	public void dragAndDropElement() throws InterruptedException {
		MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Views");
		el1.click();
		MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("Drag and Drop");
		el2.click();
		MobileElement mydragElement = (MobileElement) driver.findElementById("io.appium.android.apis:id/drag_dot_1");
		AndroidTouchAction touchAction = new AndroidTouchAction(driver);
		touchAction.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(mydragElement)))
		.moveTo(new PointOption().withCoordinates(640, 760)).release();
		
		touchAction.perform();
		Thread.sleep(2000);
	}
	
	@Test
	public void ScrollUp() throws InterruptedException {
		MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Views");
		el1.click();
		scrollUpByCoordinates(400, 2020, 420);
		Thread.sleep(2000);
		scrollUpByCoordinates(400, 2020, 420);
		Thread.sleep(2000);
		MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("Seek Bar");
		el2.click();
		(new TouchAction(driver).tap(new TapOptions().withPosition(new PointOption().withCoordinates(900, 348)))).perform();
		Thread.sleep(2000);
		(new TouchAction(driver).tap(new TapOptions().withPosition(new PointOption().withCoordinates(360, 348)))).perform();
		Thread.sleep(2000);
		
		/*
		 * tAction.press(new PointOption().withCoordinates(300, 500)).moveTo(new
		 * PointOption().withCoordinates(300, 1500)).release(); tAction.perform();
		 * Thread.sleep(2000);
		 */
	}
	
	public void scrollUpByCoordinates(int oxAxes, int oyAxes, int nyAxes) {
		TouchAction tAction = new TouchAction(driver);
		tAction.press(new PointOption().withCoordinates(oxAxes, oyAxes)).moveTo(new PointOption().withCoordinates(oxAxes, nyAxes)).release();
		tAction.perform();
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
