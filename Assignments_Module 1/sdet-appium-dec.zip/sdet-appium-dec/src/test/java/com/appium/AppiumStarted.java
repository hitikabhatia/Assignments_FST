package com.appium;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;

public class AppiumStarted {

	public AndroidDriver myDriver;
	DesiredCapabilities mydesiredCapabilities = new DesiredCapabilities();
	@Test
	public void firstAppiumMethod() throws MalformedURLException, InterruptedException {
		mydesiredCapabilities.setCapability("deviceName", "sdk_gphone_x86");
		mydesiredCapabilities.setCapability("platformName", "Android");
		mydesiredCapabilities.setCapability("platformVersion", "11");
		mydesiredCapabilities.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
		mydesiredCapabilities.setCapability("appPackage", "io.appium.android.apis");
		
		
		URL myremoteUrl = new URL("http://127.0.0.1:4723/wd/hub/");
		myDriver = new AndroidDriver(myremoteUrl, mydesiredCapabilities);
		
//		myDriver.findElementByXPath("//android.widget.TextView[@content-desc=\"Animation\"]").click();
		System.out.println(myDriver.findElementsByAccessibilityId("Animation"));
		Thread.sleep(2000);
		
		
	
	}
	
	@AfterClass
	public void closeDriver() {
		myDriver.quit();
	}
}
