package com.methods;

import org.openqa.selenium.By;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class ActionMethods {
	public static void clickOnElement(MobileBy element,AndroidDriver<MobileElement> driver) {
		driver.findElement(element).click();
	}
	
	public static void enterText(By element, String text, AndroidDriver<MobileElement> driver) {
		driver.findElement(element).sendKeys(text);
	}
	
	public void clickOnElementUsingFactory(AndroidElement element) {
		element.click();
	}
	
	public void enterTextUsingFactory(AndroidElement element, String input) {
		element.sendKeys(input);
	}
}
