package com.base;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.utils.Constants;
import com.utils.PropertyReader;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BaseClass {
	
	public AndroidDriver<MobileElement> driver;
	PropertyReader myPropertyReader = new PropertyReader();
	
	@BeforeSuite
	public void myDriverSetup() throws MalformedURLException {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability(Constants.deviceName, myPropertyReader.getPropertyValue(Constants.deviceName));
		desiredCapabilities.setCapability(Constants.platformName, myPropertyReader.getPropertyValue(Constants.platformName));
		desiredCapabilities.setCapability(Constants.platformVersion, myPropertyReader.getPropertyValue(Constants.platformVersion));
		desiredCapabilities.setCapability(Constants.appActivity, myPropertyReader.getPropertyValue(Constants.appActivity));
		desiredCapabilities.setCapability(Constants.appPackage, myPropertyReader.getPropertyValue(Constants.appPackage));

		URL remoteUrl = new URL(myPropertyReader.getPropertyValue(Constants.appiumremoteUrl));

		driver = new AndroidDriver(remoteUrl, desiredCapabilities);
	}
	
	@AfterSuite
	public void closeDriver() {
		driver.quit();
	}

}
