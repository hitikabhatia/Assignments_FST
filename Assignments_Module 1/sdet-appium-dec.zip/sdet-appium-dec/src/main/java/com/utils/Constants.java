package com.utils;

public class Constants {
	final public static String deviceName = "deviceName";
	final public static String platformName = "platformName";
	final public static String platformVersion = "platformVersion";
	final public static String appActivity = "appActivity";
	final public static String appPackage = "appPackage";
	final public static String appiumremoteUrl = "appiumremoteUrl";
	final public static String propertyReaderURL = "/src/test/resources/param.properties";
}
