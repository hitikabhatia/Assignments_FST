package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {
	
	public String getPropertyValue(String key) {
		Properties myProp = new Properties();
		String propertyValue;
		try {
			myProp.load(new FileInputStream(new File(System.getProperty("user.dir")+ Constants.propertyReaderURL)));
			propertyValue = myProp.getProperty(key);
		} catch (FileNotFoundException e) {
			propertyValue = null;
			e.printStackTrace();
		} catch (IOException e) {
			propertyValue = null;
			e.printStackTrace();
		}
		return propertyValue;
	}

}
